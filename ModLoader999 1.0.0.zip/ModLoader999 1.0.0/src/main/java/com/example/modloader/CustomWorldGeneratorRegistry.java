package com.example.modloader;

import com.example.modloader.api.CustomWorldPopulator;
import com.example.modloader.api.world.CustomOreGenerator;
import com.example.modloader.api.world.CustomStructureGenerator;
import com.example.modloader.api.world.CustomTreeGenerator;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.generator.BlockPopulator;
import org.bukkit.plugin.Plugin;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.logging.Logger;

public class CustomWorldGeneratorRegistry {

    private final Plugin plugin;
    private final Logger logger;
    private final List<CustomWorldPopulator> registeredPopulators = new ArrayList<>();
    private final List<CustomOreGenerator> registeredOreGenerators = new ArrayList<>();
    private final List<CustomTreeGenerator> registeredTreeGenerators = new ArrayList<>();
    private final List<CustomStructureGenerator> registeredStructureGenerators = new ArrayList<>();

    public CustomWorldGeneratorRegistry(Plugin plugin) {
        this.plugin = plugin;
        this.logger = plugin.getLogger();
    }

    public void registerPopulator(CustomWorldPopulator populator) {
        registeredPopulators.add(populator);
        logger.info("Registered custom world populator: " + populator.getClass().getName());
    }

    public void registerOreGenerator(CustomOreGenerator generator) {
        registeredOreGenerators.add(generator);
        logger.info("Registered custom ore generator: " + generator.getClass().getName());
    }

    public void registerTreeGenerator(CustomTreeGenerator generator) {
        registeredTreeGenerators.add(generator);
        logger.info("Registered custom tree generator: " + generator.getClass().getName());
    }

    public void registerStructureGenerator(CustomStructureGenerator generator) {
        registeredStructureGenerators.add(generator);
        logger.info("Registered custom structure generator: " + generator.getClass().getName());
    }

    public void applyPopulatorsToWorld(World world) {
        for (CustomWorldPopulator customPopulator : registeredPopulators) {
            world.getPopulators().add(new BlockPopulator() {
                @Override
                public void populate(World world, Random random, org.bukkit.Chunk chunk) {
                    customPopulator.populate(world, random, chunk);
                }
            });
            logger.info("Applied populator " + customPopulator.getClass().getName() + " to world " + world.getName());
        }

        world.getPopulators().add(new BlockPopulator() {
            @Override
            public void populate(World world, Random random, org.bukkit.Chunk chunk) {
                for (CustomOreGenerator generator : registeredOreGenerators) {
                    generator.generate(world, random, chunk.getX(), chunk.getZ());
                }
            }
        });

        world.getPopulators().add(new BlockPopulator() {
            @Override
            public void populate(World world, Random random, org.bukkit.Chunk chunk) {
                for (CustomTreeGenerator generator : registeredTreeGenerators) {
                    int x = chunk.getX() * 16 + random.nextInt(16);
                    int z = chunk.getZ() * 16 + random.nextInt(16);
                    int y = world.getHighestBlockYAt(x, z);
                    generator.generate(world, random, x, y, z);
                }
            }
        });

        world.getPopulators().add(new BlockPopulator() {
            @Override
            public void populate(World world, Random random, org.bukkit.Chunk chunk) {
                for (CustomStructureGenerator generator : registeredStructureGenerators) {
                    int x = chunk.getX() * 16 + random.nextInt(16);
                    int z = chunk.getZ() * 16 + random.nextInt(16);
                    int y = world.getHighestBlockYAt(x, z);
                    generator.generate(world, random, new org.bukkit.Location(world, x, y, z));
                }
            }
        });
    }

    public void unregisterAll() {
        registeredPopulators.clear();
        registeredOreGenerators.clear();
        registeredTreeGenerators.clear();
        registeredStructureGenerators.clear();
        logger.info("Unregistered all custom world populator, ore, tree, and structure generator definitions.");
    }
}
