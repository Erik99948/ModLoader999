package com.example.modloader.api;

import com.example.modloader.CustomBlockRegistry;
import com.example.modloader.CustomCommandRegistry;
import com.example.modloader.CustomEventListenerRegistry;
import com.example.modloader.CustomItemRegistry;
import com.example.modloader.CustomMobRegistry;
import com.example.modloader.CustomRecipeRegistry;
import com.example.modloader.CustomWorldGeneratorRegistry;
import org.bukkit.Material;
import org.bukkit.entity.EntityType;
import org.bukkit.event.Listener;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Recipe;

public class ModAPIImpl implements ModAPI {

    private final CustomItemRegistry itemRegistry;
    private final CustomMobRegistry mobRegistry;
    private final CustomBlockRegistry blockRegistry;
    private final CustomCommandRegistry commandRegistry;
    private final CustomEventListenerRegistry eventListenerRegistry;
    private final CustomRecipeRegistry recipeRegistry;
    private final CustomWorldGeneratorRegistry worldGeneratorRegistry;

    public ModAPIImpl(CustomItemRegistry itemRegistry, CustomMobRegistry mobRegistry, CustomBlockRegistry blockRegistry, CustomCommandRegistry commandRegistry, CustomEventListenerRegistry eventListenerRegistry, CustomRecipeRegistry recipeRegistry, CustomWorldGeneratorRegistry worldGeneratorRegistry) {
        this.itemRegistry = itemRegistry;
        this.mobRegistry = mobRegistry;
        this.blockRegistry = blockRegistry;
        this.commandRegistry = commandRegistry;
        this.eventListenerRegistry = eventListenerRegistry;
        this.recipeRegistry = recipeRegistry;
        this.worldGeneratorRegistry = worldGeneratorRegistry;
    }

    @Override
    public void registerItem(String itemId, ItemStack item) {
        itemRegistry.register(itemId, item);
    }

    @Override
    public void registerMob(com.example.modloader.CustomMob customMob) {
        mobRegistry.register(customMob);
    }

    @Override
    public void registerBlock(com.example.modloader.CustomBlock customBlock) {
        blockRegistry.register(customBlock);
    }

    @Override
    public void registerCommand(String commandName, ModCommandExecutor executor) {
        commandRegistry.register(commandName, executor);
    }

    @Override
    public void registerListener(Listener listener) {
        eventListenerRegistry.register(listener);
    }

    @Override
    public void registerRecipe(Recipe recipe) {
        recipeRegistry.register(recipe);
    }

    @Override
    public void registerWorldPopulator(CustomWorldPopulator populator) {
        worldGeneratorRegistry.registerPopulator(populator);
    }

    @Override
    public void registerOreGenerator(com.example.modloader.api.world.CustomOreGenerator generator) {
        worldGeneratorRegistry.registerOreGenerator(generator);
    }

    @Override
    public void registerTreeGenerator(com.example.modloader.api.world.CustomTreeGenerator generator) {
        worldGeneratorRegistry.registerTreeGenerator(generator);
    }

    @Override
    public void registerMobSpawner(com.example.modloader.api.mob.CustomMobSpawner spawner) {
        mobRegistry.registerSpawner(spawner);
    }

    @Override
    public void registerStructureGenerator(com.example.modloader.api.world.CustomStructureGenerator generator) {
        worldGeneratorRegistry.registerStructureGenerator(generator);
    }

    @Override
    public com.example.modloader.CustomMobRegistry getCustomMobRegistry() {
        return mobRegistry;
    }
}
