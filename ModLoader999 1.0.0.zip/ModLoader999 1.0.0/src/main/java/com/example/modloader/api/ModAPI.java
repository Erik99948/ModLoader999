package com.example.modloader.api;

import org.bukkit.entity.EntityType;
import org.bukkit.inventory.ItemStack;

public interface ModAPI {

    void registerItem(String itemId, ItemStack item);

    void registerMob(com.example.modloader.CustomMob customMob);

    void registerBlock(com.example.modloader.CustomBlock customBlock);

    void registerCommand(String commandName, ModCommandExecutor executor);

    void registerListener(org.bukkit.event.Listener listener);

    void registerRecipe(org.bukkit.inventory.Recipe recipe);

    void registerWorldPopulator(CustomWorldPopulator populator);

    void registerOreGenerator(com.example.modloader.api.world.CustomOreGenerator generator);

    void registerTreeGenerator(com.example.modloader.api.world.CustomTreeGenerator generator);

    void registerMobSpawner(com.example.modloader.api.mob.CustomMobSpawner spawner);

    void registerStructureGenerator(com.example.modloader.api.world.CustomStructureGenerator generator);

    com.example.modloader.CustomMobRegistry getCustomMobRegistry();
}
